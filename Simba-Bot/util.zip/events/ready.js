const chalk = require('chalk');
module.exports = client => {
  console.log(chalk.bgGreen.black('I\'m Online\nI\'m Online'));
};
